package com.funlingo.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.util.Calendar

class FunLingoWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    companion object {
        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.funlingo_widget_layout)

            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            when {
                hour < 12 -> {
                    views.setTextViewText(R.id.widget_headline, "Good Morning! ☀️")
                    views.setTextViewText(R.id.widget_status, "Ready to speak 5 minutes?")
                    views.setImageViewResource(R.id.widget_zippy, R.drawable.ic_launcher)
                }
                hour in 12..17 -> {
                    views.setTextViewText(R.id.widget_headline, "Afternoon Flow ⚡")
                    views.setTextViewText(R.id.widget_status, "Hit your 10-min speaking goal!")
                    views.setImageViewResource(R.id.widget_zippy, R.drawable.ic_launcher)
                }
                else -> {
                    views.setTextViewText(R.id.widget_headline, "Streak in Danger! 🔥")
                    views.setTextViewText(R.id.widget_status, "Speak before midnight to save flame!")
                    views.setImageViewResource(R.id.widget_zippy, R.drawable.ic_launcher)
                }
            }

            // Launch FunLingo directly on tap
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("action", "speak")
            }
            val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
