# FunLingo Flutter App
**365-Day Spoken English Fluency — Android & iOS**

## Quick Start

### Prerequisites
- Flutter SDK 3.3.0+ — https://flutter.dev
- Android Studio (Android) or Xcode on Mac (iOS)

### Run
```bash
flutter pub get
flutter run
```

### Build for Google Play Store (App Bundle)
```bash
flutter build appbundle --release
# Output: build/app/outputs/bundle/release/app-release.aab
```

### Build APK (Direct distribution)
```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

### Build for iOS (on Mac only)
```bash
flutter pub get
cd ios && pod install && cd ..
open ios/Runner.xcworkspace
# Then: Product -> Archive -> Distribute App -> App Store Connect
```

## App Details
- Package: `com.funlingo.app`
- Min Android: 5.0 (API 21)
- Min iOS: 13.0
- Contains: 365 levels, 22 real-life spoken scenarios, full offline support
