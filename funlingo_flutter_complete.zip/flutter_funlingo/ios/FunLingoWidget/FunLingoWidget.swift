import WidgetKit
import SwiftUI

struct FunLingoEntry: TimelineEntry {
    let date: Date
    let streakDays: Int
    let minutesPracticed: Int
    let targetMinutes: Int
    let stateMessage: String
    let zippyMood: String
}

struct FunLingoWidgetEntryView : View {
    var entry: FunLingoEntry

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color(hex: "0F172A"), Color(hex: "1E293B")]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text("FunLingo")
                        .font(.system(size: 11, weight: .black))
                        .foregroundColor(.white.opacity(0.85))
                    Spacer()
                    Text("🔥 \(entry.streakDays)d")
                        .font(.system(size: 12, weight: .black))
                        .foregroundColor(Color(hex: "F59E0B"))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.white.opacity(0.12))
                        .cornerRadius(8)
                }

                Spacer()

                HStack(spacing: 8) {
                    Text(entry.zippyMood == "danger" ? "🔥" : "🐥")
                        .font(.system(size: 32))

                    VStack(alignment: .leading, spacing: 2) {
                        Text(entry.stateMessage)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(.white)
                            .lineLimit(2)
                        Text("\(entry.minutesPracticed)/\(entry.targetMinutes) min today")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundColor(Color(hex: "94A3B8"))
                    }
                }

                Spacer()
            }
            .padding(12)
        }
    }
}

@main
struct FunLingoWidget: Widget {
    let kind: String = "FunLingoWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: FunLingoTimelineProvider()) { entry in
            FunLingoWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("FunLingo Spoken Streak")
        .description("Track your daily spoken English streak and living mascot Zippy.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}
